# Awesome Editor

NOTES:
This may be only for Linux, at least the beta's.
I don't know if this project will be finished or will become a big thing.

## Description

The most awesome code editor in the history of all code editors.*

Made By PrestoGuys In 2024

\* I just put that there because it sounded funny
