README - Awesome Editor
=====================================================


0 - WARRANTY DISCLAIMER
=======================
Awesome Editor v0.0.1 - A simple editor made in Python3 with Tk
Copyright (C) <2024>  <PrestoGuys>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>


1 - About
=========
v0.0.1 - BETA!!!

     The Awesome Editor is a code editor written in Python 
using Tkinter. It is still being developed. It was made by
PrestoGuys in 2024.


2 - Links
=========
License      | https://www.gnu.org/licenses/gpl-3.0.txt
Github Repo  | https://github.com/PrestoGuys/awesome_editor

Starter Code | https://www.codespeedy.com/create-a-text-editor-in-python/
